package com.example.bm;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class Chinese extends AppCompatActivity {

    private ListView lv_chinese;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_chinese);

        lv_chinese = (ListView)findViewById(R.id.lv_chinese);

        List<String> data = new ArrayList<>();

        data = new ArrayList<>();

        ArrayAdapter<String> chineseAdapter = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,data);
        lv_chinese.setAdapter(chineseAdapter);

        data.add("월궁");
        data.add("평화");
        chineseAdapter.notifyDataSetChanged();
    }

}
