package com.example.bm;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class SnackBar extends AppCompatActivity {

    private ListView lv_snackBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_snack_bar);

        lv_snackBar = (ListView)findViewById(R.id.lv_snackBar);

        List<String> data = new ArrayList<>();

        data = new ArrayList<>();

        ArrayAdapter<String> snackBarAdapter = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,data);
        lv_snackBar.setAdapter(snackBarAdapter);

        data.add("도스마스");
        data.add("맘스터치 제주대점");
        data.add("맘스터치 아라점");
        snackBarAdapter.notifyDataSetChanged();

    }

}
