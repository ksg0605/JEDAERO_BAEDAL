package com.example.bm;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class Pizza extends AppCompatActivity {

    private ListView lv_pizza;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_pizza);

        lv_pizza = (ListView)findViewById(R.id.lv_pizza);

        List<String> data = new ArrayList<>();

        data = new ArrayList<>();

        ArrayAdapter<String> pizzaAdapter = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,data);
        lv_pizza.setAdapter(pizzaAdapter);

        data.add("알볼로 제주점");
        data.add("7번가피자 아라점");
        pizzaAdapter.notifyDataSetChanged();
    }

}
