package com.example.bm;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class Korean extends AppCompatActivity {

    private ListView lv_korean;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_korean);

        lv_korean = (ListView)findViewById(R.id.lv_korean);

        List<String> data = new ArrayList<>();

        data = new ArrayList<>();

        ArrayAdapter<String> koreanAdapter = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,data);
        lv_korean.setAdapter(koreanAdapter);

        data.add("아라불족");
        data.add("부부족발");
        data.add("배꼽시계");
        data.add("개미와 베짱이");
        data.add("신전떡볶이 제주대점");
        data.add("빠샤시 떡볶이 제주대점");
        koreanAdapter.notifyDataSetChanged();

        lv_korean.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getApplicationContext(),AraBulZok.class);
                startActivity(intent);
            }
        });



    }

}
