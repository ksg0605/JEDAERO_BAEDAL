package com.example.bm;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class Chicken extends AppCompatActivity {

    private ListView lv_chicken;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_chicken);

        lv_chicken = (ListView)findViewById(R.id.lv_chicken);

        List<String> data = new ArrayList<>();

        data = new ArrayList<>();

        ArrayAdapter<String> chickenAdapter = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1);
        lv_chicken.setAdapter(chickenAdapter);

        data.add("노랑통닭 아라점");
        data.add("네네치킨 아라점");
        data.add("엄마치킨");
        data.add("명품치킨");
        data.add("숲노을치킨");
        data.add("푸라닭 제주대점");
        data.add("멕시카나 치킨");
        chickenAdapter.notifyDataSetChanged();


    }

}
